// to build a module that creates a qr code of a link provided by clien

//1. install a module which ask question to the client
//2. innstall a module which ggenrates a qr image
//3. combine both the module to create a qr img of the question

import inquirer from 'inquirer';
import qr from 'qr-image';
import fs, { writeFile } from "fs";



inquirer
  .prompt([{
    "message": "enter the link",
    "name": "URL"
  }
  ])
  .then((answers) => {
    const url = answers.URL;
    var qr_svg = qr.image(url);
    qr_svg.pipe(fs.createWriteStream('qr_img.png'));

    fs.writeFile ('url.txt',url,(err) => {
         if (err) throw err;
         console.log('The file has been saved!');
       });
  })
  .catch((error) => {
    if (error.isTtyError) {
      // Prompt couldn't be rendered in the current environment
    } else {
      // Something else went wrong
    }
  });

  
 

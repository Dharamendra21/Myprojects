// Universal Calculator JavaScript

class UniversalCalculator {
    constructor() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
        this.shouldResetScreen = false;
        this.currentCalculator = 'basic';
        
        this.initializeElements();
        this.bindEvents();
        this.setupCalculatorSwitching();
    }

    initializeElements() {
        this.previousOperandElement = document.getElementById('previous-operand');
        this.currentOperandElement = document.getElementById('current-operand');
        this.calculatorGrids = document.querySelectorAll('.calculator-grid');
        this.typeButtons = document.querySelectorAll('.calc-type-btn');
    }

    bindEvents() {
        // Number buttons
        document.querySelectorAll('[data-number]').forEach(button => {
            button.addEventListener('click', () => this.appendNumber(button.textContent));
        });

        // Operation buttons
        document.querySelectorAll('[data-operation]').forEach(button => {
            button.addEventListener('click', () => this.chooseOperation(button.textContent));
        });

        // Equals button
        document.querySelector('[data-equals]').addEventListener('click', () => this.compute());

        // Action buttons
        document.querySelector('[data-action="clear"]').addEventListener('click', () => this.clear());
        document.querySelector('[data-action="delete"]').addEventListener('click', () => this.delete());
        document.querySelector('[data-action="negate"]').addEventListener('click', () => this.negate());

        // Scientific functions
        document.querySelectorAll('[data-function]').forEach(button => {
            button.addEventListener('click', () => this.performScientificFunction(button.dataset.function));
        });

        // Programmer calculator
        this.setupProgrammerCalculator();

        // Unit converter
        this.setupUnitConverter();

        // Keyboard support
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    }

    setupCalculatorSwitching() {
        this.typeButtons.forEach(button => {
            button.addEventListener('click', () => {
                const type = button.dataset.type;
                this.switchCalculator(type);
            });
        });
    }

    switchCalculator(type) {
        // Update active button
        this.typeButtons.forEach(btn => btn.classList.remove('active'));
        document.querySelector(`[data-type="${type}"]`).classList.add('active');

        // Update active calculator
        this.calculatorGrids.forEach(grid => grid.classList.remove('active'));
        document.querySelector(`.${type}-calc`).classList.add('active');

        this.currentCalculator = type;
        this.clear();
    }

    appendNumber(number) {
        if (this.shouldResetScreen) {
            this.currentOperand = '';
            this.shouldResetScreen = false;
        }
        
        if (number === '.' && this.currentOperand.includes('.')) return;
        if (this.currentOperand === '0' && number !== '.') {
            this.currentOperand = number;
        } else {
            this.currentOperand += number;
        }
        this.updateDisplay();
    }

    chooseOperation(operation) {
        if (this.currentOperand === '') return;
        if (this.previousOperand !== '') {
            this.compute();
        }
        this.operation = operation;
        this.previousOperand = this.currentOperand;
        this.currentOperand = '0';
        this.shouldResetScreen = true;
        this.updateDisplay();
    }

    compute() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);
        
        if (isNaN(prev) || isNaN(current)) return;

        switch (this.operation) {
            case '+':
                computation = prev + current;
                break;
            case '-':
                computation = prev - current;
                break;
            case '×':
                computation = prev * current;
                break;
            case '÷':
                if (current === 0) {
                    alert('Cannot divide by zero!');
                    return;
                }
                computation = prev / current;
                break;
            default:
                return;
        }

        this.currentOperand = this.formatNumber(computation);
        this.operation = undefined;
        this.previousOperand = '';
        this.shouldResetScreen = true;
        this.updateDisplay();
    }

    formatNumber(number) {
        if (Number.isInteger(number)) {
            return number.toString();
        } else {
            return parseFloat(number.toFixed(10)).toString();
        }
    }

    clear() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
        this.updateDisplay();
    }

    delete() {
        if (this.currentOperand === '0') return;
        this.currentOperand = this.currentOperand.slice(0, -1);
        if (this.currentOperand === '') this.currentOperand = '0';
        this.updateDisplay();
    }

    negate() {
        this.currentOperand = (parseFloat(this.currentOperand) * -1).toString();
        this.updateDisplay();
    }

    performScientificFunction(func) {
        const current = parseFloat(this.currentOperand);
        let result;

        switch (func) {
            case 'sin':
                result = Math.sin(current * Math.PI / 180);
                break;
            case 'cos':
                result = Math.cos(current * Math.PI / 180);
                break;
            case 'tan':
                result = Math.tan(current * Math.PI / 180);
                break;
            case 'log':
                if (current <= 0) {
                    alert('Logarithm requires positive number');
                    return;
                }
                result = Math.log10(current);
                break;
            case 'ln':
                if (current <= 0) {
                    alert('Natural logarithm requires positive number');
                    return;
                }
                result = Math.log(current);
                break;
            case 'sqrt':
                if (current < 0) {
                    alert('Square root requires non-negative number');
                    return;
                }
                result = Math.sqrt(current);
                break;
            case 'pow':
                this.previousOperand = this.currentOperand;
                this.operation = '^';
                this.currentOperand = '0';
                this.shouldResetScreen = true;
                this.updateDisplay();
                return;
            case 'exp':
                result = Math.exp(current);
                break;
            case 'abs':
                result = Math.abs(current);
                break;
            case 'pi':
                result = Math.PI;
                break;
            default:
                return;
        }

        this.currentOperand = this.formatNumber(result);
        this.shouldResetScreen = true;
        this.updateDisplay();
    }

    setupProgrammerCalculator() {
        const programmerButtons = document.querySelectorAll('.programmer-calc button');
        programmerButtons.forEach(button => {
            if (button.dataset.base) {
                button.addEventListener('click', () => this.switchBase(button.dataset.base));
            }
        });
    }

    switchBase(base) {
        const currentValue = parseInt(this.currentOperand, 10);
        let displayValue;

        switch (base) {
            case 'hex':
                displayValue = currentValue.toString(16).toUpperCase();
                break;
            case 'dec':
                displayValue = currentValue.toString(10);
                break;
            case 'oct':
                displayValue = currentValue.toString(8);
                break;
            case 'bin':
                displayValue = currentValue.toString(2);
                break;
        }

        this.currentOperand = displayValue;
        this.updateDisplay();

        // Update active base button
        document.querySelectorAll('[data-base]').forEach(btn => btn.classList.remove('active'));
        document.querySelector(`[data-base="${base}"]`).classList.add('active');
    }

    setupUnitConverter() {
        const convertBtn = document.getElementById('convert-btn');
        const clearBtn = document.getElementById('clear-unit');
        const fromValue = document.getElementById('from-value');
        const toValue = document.getElementById('to-value');
        const fromUnit = document.getElementById('from-unit');
        const toUnit = document.getElementById('to-unit');

        convertBtn.addEventListener('click', () => {
            const value = parseFloat(fromValue.value);
            if (isNaN(value)) {
                alert('Please enter a valid number');
                return;
            }

            const from = fromUnit.value;
            const to = toUnit.value;
            const result = this.convertUnits(value, from, to);
            toValue.value = this.formatNumber(result);
        });

        clearBtn.addEventListener('click', () => {
            fromValue.value = '';
            toValue.value = '';
        });

        // Auto-convert on input change
        fromValue.addEventListener('input', () => {
            if (fromValue.value) {
                convertBtn.click();
            }
        });

        [fromUnit, toUnit].forEach(select => {
            select.addEventListener('change', () => {
                if (fromValue.value) {
                    convertBtn.click();
                }
            });
        });
    }

    convertUnits(value, fromUnit, toUnit) {
        // Conversion factors to meters
        const toMeters = {
            m: 1,
            km: 1000,
            cm: 0.01,
            mm: 0.001,
            ft: 0.3048,
            in: 0.0254
        };

        // Convert to meters first, then to target unit
        const meters = value * toMeters[fromUnit];
        return meters / toMeters[toUnit];
    }

    handleKeyboard(e) {
        if (this.currentCalculator !== 'basic' && this.currentCalculator !== 'scientific') return;

        if (e.key >= '0' && e.key <= '9') {
            this.appendNumber(e.key);
        } else if (e.key === '.') {
            this.appendNumber('.');
        } else if (e.key === '+' || e.key === '-') {
            this.chooseOperation(e.key);
        } else if (e.key === '*') {
            this.chooseOperation('×');
        } else if (e.key === '/') {
            this.chooseOperation('÷');
        } else if (e.key === 'Enter' || e.key === '=') {
            this.compute();
        } else if (e.key === 'Backspace') {
            this.delete();
        } else if (e.key === 'Escape') {
            this.clear();
        }
    }

    updateDisplay() {
        this.currentOperandElement.textContent = this.currentOperand;
        if (this.operation != null) {
            this.previousOperandElement.textContent = `${this.previousOperand} ${this.operation}`;
        } else {
            this.previousOperandElement.textContent = this.previousOperand;
        }
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new UniversalCalculator();
});

// Additional utility functions
const calculatorUtils = {
    // Memory functions (for future enhancement)
    memory: 0,
    
    memoryStore(value) {
        this.memory = parseFloat(value);
    },
    
    memoryRecall() {
        return this.memory;
    },
    
    memoryClear() {
        this.memory = 0;
    },
    
    memoryAdd(value) {
        this.memory += parseFloat(value);
    },
    
    // History functions (for future enhancement)
    history: [],
    
    addToHistory(expression, result) {
        this.history.push({ expression, result, timestamp: new Date() });
    },
    
    getHistory() {
        return this.history;
    },
    
    clearHistory() {
        this.history = [];
    }
};

// Export for potential module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UniversalCalculator;
}
